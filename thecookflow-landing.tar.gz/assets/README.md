# Assets Directory - TheCookFlow Landing

Esta carpeta contiene los assets (recursos) para la landing page de TheCookFlow.

## Archivos Necesarios

### Imágenes Principal
- **logo.png** - Logo principal de TheCookFlow (400px width recomendado)
- **bg.jpg** - Imagen de fondo para el hero section (1920x1080 recomendado)

### Iconos y Recursos
- **favicon.ico** - Icono del sitio web (ya existe en la raíz)
- **apple-touch-icon.png** - Icono para dispositivos Apple (180x180px)
- **android-chrome-192x192.png** - Icono para Android (192x192px)
- **android-chrome-512x512.png** - Icono para Android (512x512px)

### Fuentes (Opcional)
- **fuentes.woff2** - Fuentes personalizadas en formato WOFF2
- **fuentes.ttf** - Fuentes personalizadas en formato TTF

### App Store Badges
- **app-store-badge.png** - Badge para App Store
- **google-play-badge.png** - Badge para Google Play

## Notas de Implementación

1. **Logo**: Debe tener fondo transparente y ser legible sobre fondos oscuros
2. **Fondo**: La imagen de fondo se usa con overlay oscuro, debe ser de alta resolución
3. **Iconos**: Todos los iconos deben seguir las guidelines de cada plataforma
4. **Fuentes**: Actualmente usa Google Fonts (Kalam, Caveat), fuentes locales son opcionales

## Rutas de Referencias

Estos archivos se referencian en:
- **index.html**: Logo y iconos
- **style.css**: Imagen de fondo y fuentes
- **legal/**: Favicon en páginas legales

## Optimización

- Comprime todas las imágenes antes de subir
- Usa formatos modernos (WebP, AVIF) con fallbacks
- Mantén los archivos bajo 1MB cada uno para mejor carga