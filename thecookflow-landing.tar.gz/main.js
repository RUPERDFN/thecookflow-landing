// TheCookFlow Landing Page JavaScript
// Animaciones, contadores y formulario

document.addEventListener('DOMContentLoaded', function() {
    // Variables globales
    let downloadCount = 50000;
    let countersAnimated = false;
    
    // Inicializar funcionalidades
    initScrollAnimations();
    initCounterAnimations();
    initFormHandling();
    initDownloadCounter();
    initSmoothScrolling();
    
    // Contador de descargas animado
    function initDownloadCounter() {
        const downloadElement = document.getElementById('download-count');
        
        if (downloadElement) {
            setInterval(() => {
                downloadCount += Math.floor(Math.random() * 3);
                downloadElement.textContent = downloadCount.toLocaleString('es-ES') + '+';
            }, 5000);
        }
    }
    
    // Animaciones al hacer scroll
    function initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observar elementos que necesitan animación
        const animatedElements = document.querySelectorAll(
            '.problem-card, .benefit-card, .testimonial-card, .trust-box'
        );
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    }
    
    // Animación de contadores en la sección de beneficios
    function initCounterAnimations() {
        const benefitsSection = document.querySelector('.benefits-section');
        
        if (!benefitsSection) return;
        
        const observerOptions = {
            threshold: 0.3
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !countersAnimated) {
                    animateCounters();
                    countersAnimated = true;
                }
            });
        }, observerOptions);
        
        observer.observe(benefitsSection);
    }
    
    function animateCounters() {
        const counters = document.querySelectorAll('.stat-number[data-target]');
        const familiesCounter = document.querySelector('[data-families]');
        
        counters.forEach((counter, index) => {
            const target = parseInt(counter.getAttribute('data-target'));
            animateCounter(counter, target, 2000, index);
        });
        
        // Animar contador de familias
        if (familiesCounter) {
            animateCounter(familiesCounter, 50000, 2000, 0, true);
        }
    }
    
    function animateCounter(element, target, duration, delay = 0, isFamilies = false) {
        setTimeout(() => {
            const steps = 60;
            const stepTime = duration / steps;
            let current = 0;
            
            const interval = setInterval(() => {
                current += target / steps;
                
                if (current >= target) {
                    current = target;
                    clearInterval(interval);
                }
                
                if (isFamilies) {
                    element.textContent = Math.floor(current).toLocaleString('es-ES') + '+ familias';
                } else {
                    const suffix = target >= 1000 ? '+' : (target <= 100 ? '%' : '+');
                    element.textContent = Math.floor(current) + suffix;
                }
            }, stepTime);
        }, delay * 200);
    }
    
    // Manejo del formulario de email
    function initFormHandling() {
        const form = document.querySelector('.email-form');
        const emailInput = document.querySelector('.email-input');
        const submitButton = document.querySelector('.email-button');
        
        if (!form) return;
        
        form.addEventListener('submit', handleFormSubmit);
        
        // Validación en tiempo real
        if (emailInput) {
            emailInput.addEventListener('input', function() {
                validateEmail(this.value);
            });
        }
    }
    
    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const emailInput = document.querySelector('.email-input');
        
        if (!emailInput) return false;
        
        if (emailRegex.test(email)) {
            emailInput.style.borderColor = 'rgba(74, 155, 142, 0.8)';
            emailInput.style.boxShadow = '0 0 0 3px rgba(74, 155, 142, 0.2)';
            return true;
        } else {
            emailInput.style.borderColor = 'rgba(255, 107, 107, 0.8)';
            emailInput.style.boxShadow = '0 0 0 3px rgba(255, 107, 107, 0.2)';
            return false;
        }
    }
    
    async function handleFormSubmit(event) {
        event.preventDefault();
        
        const form = event.target;
        const emailInput = form.querySelector('input[name="email"]');
        const submitButton = form.querySelector('.email-button');
        const originalButtonText = submitButton.textContent;
        
        // Validar email
        if (!validateEmail(emailInput.value)) {
            showMessage('Por favor, introduce un email válido', 'error');
            return;
        }
        
        // Estado de carga
        submitButton.textContent = '⏳ Enviando...';
        submitButton.disabled = true;
        form.classList.add('loading');
        
        try {
            // Enviar a Formspree (reemplaza con tu endpoint real)
            const formData = new FormData(form);
            
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (response.ok) {
                showSuccessMessage();
                emailInput.value = '';
                
                // Evento de tracking (Google Analytics, etc.)
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'email_signup', {
                        'event_category': 'engagement',
                        'event_label': 'landing_page'
                    });
                }
            } else {
                throw new Error('Error en el servidor');
            }
        } catch (error) {
            console.error('Error enviando formulario:', error);
            showMessage('Ha ocurrido un error. Por favor, inténtalo de nuevo.', 'error');
        } finally {
            // Restaurar estado
            submitButton.textContent = originalButtonText;
            submitButton.disabled = false;
            form.classList.remove('loading');
        }
    }
    
    function showSuccessMessage() {
        const form = document.querySelector('.email-form');
        const successHtml = `
            <div class="form-success">
                <h3>🎉 ¡Perfecto!</h3>
                <p>Te hemos enviado el acceso gratuito a tu email.</p>
                <p>Revisa tu bandeja de entrada (y spam) en unos minutos.</p>
            </div>
        `;
        
        form.innerHTML = successHtml;
        
        // Scroll suave al mensaje de éxito
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    function showMessage(message, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `form-message form-message-${type}`;
        messageDiv.textContent = message;
        
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 2rem;
            border-radius: 10px;
            color: white;
            font-weight: bold;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            ${type === 'error' ? 'background: #e74c3c;' : 'background: #4a9b8e;'}
        `;
        
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => messageDiv.remove(), 300);
        }, 3000);
    }
    
    // Scroll suave para anchors
    function initSmoothScrolling() {
        const scrollLinks = document.querySelectorAll('a[href^="#"]');
        
        scrollLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
    
    // Efectos de hover mejorados para cards
    function initCardEffects() {
        const cards = document.querySelectorAll('.problem-card, .benefit-card, .testimonial-card');
        
        cards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    }
    
    // Parallax effect ligero para las partículas
    function initParallaxEffect() {
        const particles = document.querySelectorAll('.particle, .star');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            particles.forEach((particle, index) => {
                const speed = 0.5 + (index % 3) * 0.2;
                particle.style.transform = `translateY(${rate * speed}px)`;
            });
        });
    }
    
    // Detectar si el usuario prefiere animaciones reducidas
    function respectsReducedMotion() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    
    // Inicializar efectos adicionales si las animaciones están habilitadas
    if (!respectsReducedMotion()) {
        initCardEffects();
        initParallaxEffect();
    }
    
    // Lazy loading para imágenes (si las hay)
    function initLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });
            
            images.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback para navegadores que no soporten IntersectionObserver
            images.forEach(img => {
                img.src = img.dataset.src;
                img.classList.remove('lazy');
            });
        }
    }
    
    initLazyLoading();
    
    // Manejar cambios de tema del sistema
    function initThemeDetection() {
        const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
        
        function handleThemeChange(e) {
            // El sitio ya está optimizado para modo oscuro
            // Aquí podrías agregar ajustes adicionales si fuera necesario
            console.log('Theme changed to:', e.matches ? 'dark' : 'light');
        }
        
        darkModeQuery.addListener(handleThemeChange);
        handleThemeChange(darkModeQuery);
    }
    
    initThemeDetection();
    
    // Analytics y tracking (opcional)
    function initAnalytics() {
        // Tracking de scroll depth
        let maxScroll = 0;
        
        window.addEventListener('scroll', () => {
            const scrollPercent = Math.round(
                (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100
            );
            
            if (scrollPercent > maxScroll && scrollPercent % 25 === 0) {
                maxScroll = scrollPercent;
                
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'scroll', {
                        'event_category': 'engagement',
                        'event_label': `${scrollPercent}%`,
                        'value': scrollPercent
                    });
                }
            }
        });
        
        // Tracking de tiempo en página
        let timeOnPage = 0;
        const timeInterval = setInterval(() => {
            timeOnPage += 15;
            
            // Enviar evento cada 2 minutos
            if (timeOnPage % 120 === 0 && typeof gtag !== 'undefined') {
                gtag('event', 'timing_complete', {
                    'name': 'page_view',
                    'value': timeOnPage
                });
            }
        }, 15000);
        
        // Limpiar interval al cerrar página
        window.addEventListener('beforeunload', () => {
            clearInterval(timeInterval);
        });
    }
    
    // Solo inicializar analytics si hay GA configurado
    if (typeof gtag !== 'undefined') {
        initAnalytics();
    }
});

// Funciones globales para eventos externos
window.TheCookFlow = {
    // Función para mostrar mensajes desde el exterior
    showMessage: function(message, type = 'info') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `form-message form-message-${type}`;
        messageDiv.textContent = message;
        
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 2rem;
            border-radius: 10px;
            color: white;
            font-weight: bold;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            background: ${type === 'error' ? '#e74c3c' : type === 'success' ? '#4a9b8e' : '#3498db'};
        `;
        
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => messageDiv.remove(), 300);
        }, 3000);
    },
    
    // Función para scroll suave a sección
    scrollToSection: function(sectionId) {
        const element = document.getElementById(sectionId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
};

// CSS adicional para las animaciones de mensajes
const additionalStyles = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .lazy {
        opacity: 0;
        transition: opacity 0.3s;
    }
    
    .form-message {
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
`;

// Insertar estilos adicionales
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);